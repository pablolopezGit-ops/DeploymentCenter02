import { Component } from '@angular/core';

@Component({ 
  selector: 'app-component',
  template: `
    <h1>Hello World</h1>
  `
})
export class AppComponent {
  
  constructor() {

  }
  
}